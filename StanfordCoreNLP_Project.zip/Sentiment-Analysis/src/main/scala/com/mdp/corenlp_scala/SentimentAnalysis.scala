
package com.mdp.corenlp_scala

import java.io._
import util.control.Breaks._
import scala.io.Source
import java.io.File
import java.nio.charset.Charset
import java.util.Properties
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import edu.stanford.nlp.coref.CorefCoreAnnotations
import edu.stanford.nlp.ling.CoreAnnotations
import edu.stanford.nlp.neural.rnn.RNNCoreAnnotations
import edu.stanford.nlp.pipeline.{Annotation, StanfordCoreNLP}
import edu.stanford.nlp.sentiment.SentimentCoreAnnotations
import edu.stanford.nlp.sentiment.SentimentCoreAnnotations.SentimentAnnotatedTree
import edu.stanford.nlp.util.CoreMap
import scala.collection.JavaConversions._
import scala.collection.mutable.ListBuffer
import scala.collection.JavaConverters._


object SentimentAnalysisExample {
  
  lazy val pipeline2 = {
    val props = new Properties()
    props.setProperty("annotators", "tokenize, ssplit, pos, lemma, parse, sentiment")
    new StanfordCoreNLP(props)
  }


  def getSentiment(sentiment: Int): String = sentiment match {
    case x if x == 0 || x == 1 => "Negative"
    case 2 => "Neutral"
    case x if x == 3 || x == 4 => "Positive"
  }

   def computeWeightedSentiment(feedback: String): Double = {
	if(feedback.isEmpty()||feedback==null){

        return 0.0
       }



    val annotation = pipeline2.process(feedback)
    val sentiments: ListBuffer[Double] = ListBuffer()
    val sizes: ListBuffer[Int] = ListBuffer()
    var nosent = 0
    var nosent1 = 0.0
    var result = 0.0   

    for (sentence <- annotation.get(classOf[CoreAnnotations.SentencesAnnotation])) {
      val tree = sentence.get(classOf[SentimentCoreAnnotations.SentimentAnnotatedTree])
      val sentiment = RNNCoreAnnotations.getPredictedClass(tree)

      sentiments += sentiment.toDouble
      sizes += sentence.toString.length
      nosent = nosent+1
      nosent1 = nosent1+sentiment.toDouble
    }

    val weightedSentiment = if (sentiments.isEmpty) {
      -1
    } else {
      val weightedSentiments = (sentiments, sizes).zipped.map((sentiment, size) => sentiment * size)
      weightedSentiments.sum / sizes.sum
      
      
      
   }
   result = nosent1 / nosent
   return result

   }
   
  def main(args: Array[String]): Unit = {
    val props: Properties = new Properties()
    props.put("annotators", "tokenize, ssplit, parse, sentiment")

    val pipeline: StanfordCoreNLP = new StanfordCoreNLP(props)
// read some text from a file - Uncomment this and comment the val text = "Quick...." below to load from a file
    //val inputFile: File = new File("src/test/resources/sample-content.txt")
    //val text: String = Files.toString(inputFile, Charset.forName("UTF-8"))
    val text1 = "I was really disappointed.The curriculum requires a lot of effort. It should not be underestimated under any circumstances and at any cost. Its questions are very important. Training is more important than anything else. It was an interesting subject, however, because of the subject pressure, we could not be creative in it.Its lessons are not interrelated especially the last chapter had nothing to do with the rest of the chapters.It was a condensed subject, not an easy one.I was expecting it to be easy but it unfortunately failed my expectations in the exam."
    val text2 = "An amazing and very useful subject."
    // create blank annotator
    val document1: Annotation = new Annotation(text1)
    val document2: Annotation = new Annotation(text2)

    // run all Annotators
    pipeline.annotate(document1)
    pipeline.annotate(document2)

    
    val sentiments: ListBuffer[Double] = ListBuffer()
    val sizes: ListBuffer[Int] = ListBuffer()

    val sentences1: List[CoreMap] = document1.get(classOf[CoreAnnotations.SentencesAnnotation]).asScala.toList
    val sentences2: List[CoreMap] = document2.get(classOf[CoreAnnotations.SentencesAnnotation]).asScala.toList

    // Check if positive sentiment sentence is truly positive
    val sent = sentences1
      .map(sentence => (sentence, sentence.get(classOf[SentimentAnnotatedTree])))
      .map { case (sentence, tree) => (sentence.toString, RNNCoreAnnotations.getPredictedClass(tree))}
    println(sent)

    // Check if the negative sentiment sentence is truly negative
    sentences2
      .map(sentence => (sentence, sentence.get(classOf[SentimentAnnotatedTree])))
      .map { case (sentence, tree) => (sentence.toString, getSentiment(RNNCoreAnnotations.getPredictedClass(tree))) }
      .foreach(println)

      val sent1 = computeWeightedSentiment(text1)
     // println(sent1)
      
      var firstRecord = 0
      var text="Student_ID, What do you think of subject 60-MATH? Did this subject fulfil your expectations? (Please write 5 sentences at least) your answer, Sentiment_score, What are the proposed improvement methods to improve teaching of subject 60-MATH?, Sentiment_score, Did you need help in studying subject 60-MATH?, Sentiment_score, What do you think of subject 101CS? Did this subject fulfil your expectations? (Please write 5 sentences at least), Sentiment_score, What are the proposed improvement methods to improve teaching of subject 101CS?, Sentiment_score, Did you need help in studying subject 60 MATH?, Sentiment_score, What do you think of subject 101CS? Did this subject fulfil your expectations? (Please write 5 sentences at least),Sentiment_score, What are the proposed improvement methods to improve teaching of subject 101CS?, Sentiment_score, Did you need help in studying subject 60 MATH?, Sentiment_score, Avg_sentiment_score, Predicted_sentiment"
      val bufferedSource = Source.fromFile("student.csv")
      for (line <- bufferedSource.getLines) {
//      if(firstRecord == 0){ 
  //    firstRecord = 5  
    //  break
     // }
     // else{
      var cols = line.split(",",-1)
        // do whatever you want with the columns here
       // println(s"${cols(0)}|${cols(1)}|${cols(2)}|${cols(3)}")
        
      // println(cols.length)
       val col1 = computeWeightedSentiment(cols(3).toString)
       val col2 = computeWeightedSentiment(cols(4).toString)
       val col3 = computeWeightedSentiment(cols(5).toString)
       var col4 = 0.0
      
       if(cols(7) != null && !cols(7).isEmpty()){       
       println(cols(7).toString)        
        
        col4 = computeWeightedSentiment(cols(7).toString)
	}
       else{       
        col4=0
        cols(7)="NAN"
	
       }
       val col5 = computeWeightedSentiment(cols(8).toString)
       val col6 = computeWeightedSentiment(cols(9).toString)
       val col7 = computeWeightedSentiment(cols(11).toString)
       val col8 = computeWeightedSentiment(cols(12).toString)
       val col9 = computeWeightedSentiment(cols(13).toString)  

       val avg = (col1+col2+col3+col4+col5+col6+col7+col8+col9)/9
        val se = getSentiment(avg.toInt)

//       println(cols(1).toString+"       "+cols(3).toString+"    "+col1.toString+"       "+cols(4).toString+"    "+col2.toString +"       "+cols(5).toString+"    "+col3.$)
      var output= cols(1).toString+","+cols(3).toString+","+col1.toString+","+cols(4).toString+","+col2.toString +","+cols(5).toString+","+col3.toString +","+cols(7).toString+","+col4.toString +","+cols(8).toString+","+col5.toString +","+cols(9).toString+","+col6.toString +","+cols(11).toString+","+col7.toString +","+cols(12).toString+","+col8.toString +","+cols(13).toString+","+col9.toString+","+avg.toString+","+se.toString+"\n"

      text=text+output
   // }
    }
    bufferedSource.close
    val file = new File("output.csv")
    val bw = new BufferedWriter(new FileWriter(file))
    bw.write(text)
    bw.close()
  }
  

}

